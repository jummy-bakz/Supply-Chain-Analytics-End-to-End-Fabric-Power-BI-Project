CREATE DATABASE supply_chain_ext;
USE supply_chain_ext;

CREATE TABLE raw_sales (
  `Order ID` VARCHAR(50),
  `Product` VARCHAR(200),
  `Quantity Ordered` VARCHAR(50),
  `Price Each` VARCHAR(50),
  `Order Date` VARCHAR(50),
  `Purchase Address` VARCHAR(300)
);

select* from raw_sales;

CREATE OR REPLACE VIEW v_sales_parsed AS
SELECT
  CAST(`Order ID` AS UNSIGNED)                AS order_id,
  TRIM(`Product`)                             AS product,
  CAST(`Quantity Ordered` AS SIGNED)          AS qty,
  CAST(`Price Each` AS DECIMAL(10,2))         AS price,
  STR_TO_DATE(`Order Date`, '%m/%d/%Y %H:%i') AS order_datetime,
  DATE(STR_TO_DATE(`Order Date`, '%m/%d/%Y %H:%i')) AS order_date,
  `Purchase Address`                          AS purchase_address,
  CAST(`Quantity Ordered` AS SIGNED) * CAST(`Price Each` AS DECIMAL(10,2)) AS revenue
FROM raw_sales
WHERE `Order ID` IS NOT NULL AND `Order ID` <> '';

SELECT * FROM v_sales_parsed LIMIT 10;

USE supply_chain_ext;

DELIMITER $$

DROP PROCEDURE IF EXISTS usp_GetSalesIncremental_ByDate $$
CREATE PROCEDURE usp_GetSalesIncremental_ByDate(IN p_SinceDate DATE)
BEGIN
  SELECT
    order_id,
    order_datetime,
    order_date,
    product,
    qty,
    price,
    revenue,
    purchase_address
  FROM v_sales_parsed
  WHERE order_date > p_SinceDate
  ORDER BY order_date, order_id;
END $$
DELIMITER ;

CALL usp_GetSalesIncremental_ByDate('2018-12-31');




