#!/usr/bin/env python
# coding: utf-8

# ## Notebook 1
# 
# New notebook

# In[1]:


from pyspark.sql import functions as F

# Read all CSVs (Bronze)
df = spark.read.option("header", True).csv("Files/*.csv")

# Drop header/noise rows
df = df.filter(~F.col("Order Date").rlike("[A-Za-z]"))

# ---- 1) Make column names Delta-safe (no spaces) ----
for c in df.columns:
    df = df.withColumnRenamed(c, c.replace(" ", "_"))

# Now columns are: Order_ID, Product, Quantity_Ordered, Price_Each, Order_Date, Purchase_Address

# ---- 2) Robust datetime parsing (handles '2/18/2019 1:35' and '04/19/19 08:46') ----
parsed_ts = F.coalesce(
    F.to_timestamp("Order_Date", "M/d/yyyy H:mm"),
    F.to_timestamp("Order_Date", "MM/dd/yyyy HH:mm"),
    F.to_timestamp("Order_Date", "M/d/yy H:mm"),
    F.to_timestamp("Order_Date", "MM/dd/yy HH:mm")
)

df = (df
      .withColumn("OrderDate", parsed_ts)
      .withColumn("QuantityOrdered", F.col("Quantity_Ordered").cast("int"))
      .withColumn("PriceEach", F.col("Price_Each").cast("double"))
      .withColumn("OrderID", F.col("Order_ID").cast("long"))
)

# Optional fallback if you ever still see parse errors:
# spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")

# ---- 3) Parse geo + revenue ----
addr = F.col("Purchase_Address")
df = (df
      .withColumn("Street", F.regexp_extract(addr, r"^(.*?),", 1))
      .withColumn("City",   F.regexp_extract(addr, r",\s*([^,]+),", 1))
      .withColumn("State",  F.regexp_extract(addr, r",\s*([A-Z]{2})\s", 1))
      .withColumn("Zip",    F.regexp_extract(addr, r"\s(\d{5})(?:-\d{4})?$", 1))
      .withColumn("Revenue", F.col("QuantityOrdered") * F.col("PriceEach"))
)

# Keep only clean rows
df = df.filter(F.col("OrderDate").isNotNull() & F.col("QuantityOrdered").isNotNull() & F.col("PriceEach").isNotNull())

# ---- 4) Save as managed Delta table in your default Lakehouse (Silver) ----
df.write.format("delta").mode("overwrite").saveAsTable("Sales_Silver")

# Verify
spark.sql("SHOW TABLES").show(truncate=False)
spark.sql("SELECT COUNT(*) AS rows FROM Sales_Silver").show()


# In[2]:


from pyspark.sql import functions as F
from pyspark.sql.window import Window

silver = spark.read.table("Sales_Silver")

# dimProduct
dimProduct = (silver.select("Product").distinct()
              .withColumn("ProductKey", F.row_number().over(Window.orderBy("Product")))
              .select("ProductKey","Product"))
dimProduct.write.mode("overwrite").saveAsTable("dimProduct")

# dimGeo
dimGeo = (silver.select("City","State").distinct()
          .withColumn("GeoKey", F.row_number().over(Window.orderBy("State","City")))
          .select("GeoKey","City","State"))
dimGeo.write.mode("overwrite").saveAsTable("dimGeo")

# dimDate
dimDate = (
    silver.withColumn("FullDate", F.to_date("OrderDate"))
    .select("FullDate").distinct()
    .withColumn("DateKey", F.date_format("FullDate","yyyyMMdd").cast("int"))
    .withColumn("Year", F.year("FullDate"))
    .withColumn("Quarter", F.quarter("FullDate"))
    .withColumn("Month", F.month("FullDate"))  # numeric 1–12
    .withColumn("MonthName", F.date_format("FullDate", "MMMM"))   # January, February
    .withColumn("MonthShort", F.date_format("FullDate", "MMM"))   # Jan, Feb
    .withColumn("Day", F.dayofmonth("FullDate"))
    .withColumn("DayName", F.date_format("FullDate", "EEEE"))
)

dimDate.write.mode("overwrite").saveAsTable("dimDate")

# factSales
factSales = (silver.withColumn("DateKey", F.date_format("OrderDate","yyyyMMdd").cast("int"))
             .join(dimProduct, on="Product", how="inner")
             .join(dimGeo, on=["City","State"], how="inner")
             .select(
                 F.col("OrderID"),
                 F.col("DateKey"),
                 F.col("ProductKey"),
                 F.col("GeoKey"),
                 F.col("QuantityOrdered").alias("Quantity"),
                 F.col("PriceEach").alias("UnitPrice"),
                 F.col("Revenue")
             ))
factSales.write.mode("overwrite").saveAsTable("factSales")

# quick verify
spark.sql("SHOW TABLES").show(truncate=False)

